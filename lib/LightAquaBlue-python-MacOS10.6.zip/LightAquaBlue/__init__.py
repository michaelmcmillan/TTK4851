import objc as _objc

__bundle__ = _objc.initFrameworkWrapper("LightAquaBlue",
    frameworkIdentifier="com.blammit.LightAquaBlue",
    frameworkPath=_objc.pathForFramework(
        "/Library/Frameworks/LightAquaBlue.framework"),
    globals=globals())
